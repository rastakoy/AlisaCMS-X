-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Сен 09 2016 г., 23:02
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `alisa_x`
--

-- --------------------------------------------------------

--
-- Структура таблицы `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(20) COLLATE cp1251_ukrainian_ci NOT NULL,
  `password` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `admins`
--

INSERT INTO `admins` (`id`, `login`, `password`, `addDate`) VALUES
(1, 'superadmin', '098f6bcd4621d373cade4e832627b4f6', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `colors`
--

CREATE TABLE IF NOT EXISTS `colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `folder` int(11) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `letters` varchar(60) COLLATE cp1251_ukrainian_ci NOT NULL,
  `content` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `metaDescription` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime DEFAULT NULL,
  `colorize` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `colors`
--

INSERT INTO `colors` (`id`, `parent`, `folder`, `prior`, `link`, `filter`, `name`, `name_ukr`, `name_eng`, `letters`, `content`, `visible`, `tmp`, `trash`, `metaTitle`, `metaDescription`, `addDate`, `colorize`) VALUES
(1, 0, 0, 0, '', 0, '', '', '', '', '', 0, 0, 0, '', '', '2016-09-08 19:33:25', 0),
(2, 0, 0, 0, '', 0, '', '', '', '', '', 0, 0, 0, '', '', '2016-09-08 19:33:28', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `filters`
--

CREATE TABLE IF NOT EXISTS `filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL DEFAULT '0',
  `name` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_dch` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_frn` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(20) COLLATE cp1251_ukrainian_ci NOT NULL,
  `tableName` varchar(30) COLLATE cp1251_ukrainian_ci NOT NULL,
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `type` varchar(20) COLLATE cp1251_ukrainian_ci NOT NULL,
  `datatype` varchar(30) COLLATE cp1251_ukrainian_ci NOT NULL,
  `datalength` int(3) NOT NULL,
  `datadefault` varchar(30) COLLATE cp1251_ukrainian_ci NOT NULL,
  `folder` int(1) NOT NULL DEFAULT '0',
  `config` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `trash` int(1) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `txtfield` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `txtfield_eng` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `txtfield_ukr` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `external` int(1) NOT NULL DEFAULT '0',
  `inFilter` int(1) NOT NULL DEFAULT '0',
  `addDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=35 ;

--
-- Дамп данных таблицы `filters`
--

INSERT INTO `filters` (`id`, `parent`, `name`, `name_eng`, `name_dch`, `name_frn`, `name_ukr`, `tableName`, `link`, `type`, `datatype`, `datalength`, `datadefault`, `folder`, `config`, `visible`, `trash`, `prior`, `tmp`, `txtfield`, `txtfield_eng`, `txtfield_ukr`, `external`, `inFilter`, `addDate`) VALUES
(1, 0, 'Каталог-товаров 3', '', '', '', 'ukr', '', 'filter-1', '', '', 0, '', 1, '', 1, 0, 5, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(2, 1, 'Название', '', '', '', '', '', 'name', '', '', 0, '', 0, '', 1, 0, 10, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(3, 1, 'Миниописание', '', '', '', '', '', 'mini', '', '', 0, '', 0, '', 1, 0, 20, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(4, 1, 'HTML-путь', '', '', '', '', '', 'link', '', '', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"link","isprev":"0"}', 1, 0, 30, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(5, 1, 'Родитель', '', '', '', '', '', 'parent', '', '', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"parent","isprev":"0"}', 1, 0, 40, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(6, 1, 'Цена', '', '', '', '', '', 'price', '', '', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"price","isprev":"0"}', 1, 0, 50, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(7, 1, 'Изображения', '', '', '', '', '', 'images', '', '', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"images","isprev":"0"}', 1, 0, 60, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(8, 1, 'Описание', '', '', '', '', '', 'content', '', '', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"content","isprev":"0"}', 1, 0, 70, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(9, 1, 'Показ в сайте', '', '', '', '', '', 'visible', '', '', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"visible","isprev":"0"}', 1, 0, 80, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(10, 1, 'Буквенный код', '', '', '', '', '', 'letters', '', '', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"letters","isprev":"0"}', 1, 0, 90, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(11, 1, 'Дата добавления', '', '', '', '', '', 'addDate', '', '', 0, '', 0, '', 1, 0, 100, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(12, 1, 'Заголовок', '', '', '', '', '', 'metaTitle', '', '', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"metaTitle","isprev":"0"}', 1, 0, 110, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(13, 1, 'Описание заголовка', '', '', '', '', '', 'metaDescription', '', '', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"metaDescription","isprev":"0"}', 1, 0, 120, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(14, 1, 'Новая запись', '', '', '', '', '', 'tmp', '', '', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"","isprev":"0"}', 1, 0, 130, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(15, 1, 'Новая опция', '', '', '', '', '', 'newopt', '', '', 0, '', 0, '', 1, 0, 140, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(16, 0, 'Цвета', '', '', '', '', '', 'colors', '', '', 0, '', 1, '', 1, 0, 20, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(17, 16, 'Название цвета', '', '', '', '', '', 'name', '', 'varchar', 20, '', 0, '', 1, 0, 10, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(18, 16, 'Выбор цвета', '', '', '', '', '', 'color', '', 'varchar:colors', 7, '#FF0000', 0, '', 1, 0, 30, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(31, 16, 'test', '', '', '', '', '', 'asdewq', '', 'int', 1, '', 0, '', 0, 0, 20, 0, '', '', '', 0, 0, '2016-09-09 20:33:03'),
(32, 16, 'test 23', '', '', '', '', '', 'colorize', '', 'varchar:colors', 7, '23', 0, '', 0, 0, 40, 0, '', '', '', 0, 0, '2016-09-09 21:08:49'),
(33, 0, 'Новый фильтр', '', '', '', '', '', 'newfilter', '', '', 0, '', 1, '', 1, 0, 0, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(34, 33, 'Название', '', '', '', '', '', 'name', '', 'varchar', 100, '', 0, '', 0, 0, 0, 0, '', '', '', 0, 0, '2016-09-09 21:20:46');

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prior` int(11) NOT NULL DEFAULT '0',
  `userId` int(11) NOT NULL,
  `name` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `cont` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `alt` varchar(255) COLLATE cp1251_ukrainian_ci NOT NULL,
  `title` varchar(255) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime NOT NULL,
  `externalId` int(11) NOT NULL DEFAULT '0',
  `table` varchar(255) COLLATE cp1251_ukrainian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=34 ;

--
-- Дамп данных таблицы `images`
--

INSERT INTO `images` (`id`, `prior`, `userId`, `name`, `cont`, `alt`, `title`, `addDate`, `externalId`, `table`) VALUES
(1, 90, 0, '1.jpg', '', 'какой-то альт', 'какой-то тайтл', '0000-00-00 00:00:00', 4, 'items'),
(2, 130, 0, '2.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(3, 180, 0, '3.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(4, 170, 0, '4.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(5, 80, 0, '5.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(6, 160, 0, '6.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(7, 60, 0, '7.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(8, 70, 0, '8.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(9, 150, 0, '9.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(10, 100, 0, '10.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(11, 190, 0, '11.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(12, 10, 0, '12.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(13, 50, 0, '13.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(14, 10, 0, '14.jpg', '', '', '', '0000-00-00 00:00:00', 5, 'items'),
(15, 40, 0, '15.jpg', '', '', '', '0000-00-00 00:00:00', 5, 'items'),
(16, 30, 0, '16.jpg', '', '', '', '0000-00-00 00:00:00', 5, 'items'),
(17, 120, 0, '17.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(18, 140, 0, '18.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(19, 40, 0, '19.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(20, 110, 0, '20.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(21, 20, 0, '21.jpg', '', '', '', '0000-00-00 00:00:00', 5, 'items'),
(22, 10, 0, '22.jpg', '', '', '', '0000-00-00 00:00:00', 21, 'items'),
(23, 20, 0, '23.jpg', '', '', '', '0000-00-00 00:00:00', 21, 'items'),
(24, 20, 0, '24.jpg', '', '', '', '0000-00-00 00:00:00', 42, 'items'),
(25, 10, 0, '25.jpg', '', '', '', '0000-00-00 00:00:00', 42, 'items'),
(26, 0, 0, '26.jpg', '', '', '', '0000-00-00 00:00:00', 43, 'items'),
(27, 0, 0, '27.jpg', '', '', '', '0000-00-00 00:00:00', 26, 'items'),
(28, 0, 0, '28.jpg', '', '', '', '0000-00-00 00:00:00', 26, 'items'),
(29, 0, 0, '29.jpg', '', '', '', '0000-00-00 00:00:00', 45, 'items'),
(30, 20, 0, '30.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(31, 30, 0, '31.jpg', '', '', '', '0000-00-00 00:00:00', 4, 'items'),
(32, 0, 0, '32.jpg', '', '', '', '0000-00-00 00:00:00', 45, 'items'),
(33, 0, 0, '33.jpg', '', '', '', '0000-00-00 00:00:00', 46, 'items');

-- --------------------------------------------------------

--
-- Структура таблицы `items`
--

CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `folder` int(11) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `name` varchar(150) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `letters` varchar(60) COLLATE cp1251_ukrainian_ci NOT NULL,
  `content` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `content_ukr` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `metaDescription` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=48 ;

--
-- Дамп данных таблицы `items`
--

INSERT INTO `items` (`id`, `parent`, `folder`, `prior`, `link`, `filter`, `name`, `name_ukr`, `name_eng`, `letters`, `content`, `content_ukr`, `visible`, `tmp`, `trash`, `metaTitle`, `metaDescription`, `addDate`) VALUES
(1, 0, 1, 10, 'motos', 0, 'Мотоблоки', '', '', 'AAA', '', '', 1, 0, 0, '', '', NULL),
(2, 0, 1, 20, '', 0, 'Культиваторы', '', '', 'AAB', '', '', 1, 0, 0, '', '', NULL),
(3, 1, 1, 40, '', 0, 'Бензиновые (до 10 л.с.)', '', '', '', '', '', 1, 0, 0, '', '', NULL),
(4, 1, 0, 50, 'test', 0, 'Daewoo 2000Е тест', 'укр', '', '', '<p>фыв ы<em>фв фывфы вы</em>ф<strong><em>вфывфыв</em></strong></p>\n<p><strong><em>\\\\'''' &nbsp; &nbsp; &nbsp;\\\\''</em></strong></p>\n<p><strong><em>ьотбьтбь</em></strong></p>', '', 1, 0, 0, '', '', NULL),
(5, 1, 0, 60, 'test2', 0, 'Мотоблок 2 с длинным названием для проверки длинных названий как справится система с длинным названием и что из этого в итоге', '', '', '', '', '', 1, 0, 0, '', '', NULL),
(21, 1, 1, 10, 'testoooo', 0, 'test', 'украинська', '', 'AAAAAC', '', '', 1, 0, 0, '', '', NULL),
(22, 1, 1, 30, 'test_2', 0, 'test 2', '', '', 'AAAAAB', '', '', 1, 0, 0, '', '', NULL),
(26, 21, 1, 10, 'subtest', 0, 'subtest', '', '', '', '', '', 1, 0, 0, '', '', NULL),
(42, 21, 0, 30, 'qwerty', 0, 'qwerty', 'украинська', '', '', '', '', 0, 0, 0, '', '', '2016-08-28 19:41:37'),
(43, 21, 0, 20, 'poziciya_2', 0, 'Позиция №2', '', '', '', '', '', 0, 0, 0, '', '', '2016-08-28 19:50:48'),
(44, 1, 1, 20, 'novaya_gruppa_v_motobloki', 0, 'Новая группа в мотоблоки', '', '', '', '', '', 1, 0, 0, '', '', NULL),
(45, 1, 0, 70, 'hnya', 0, 'Чо за хуйня', '', '', '', '', '', 1, 0, 0, '', '', '2016-08-31 10:14:34'),
(46, 1, 0, 80, '', 0, 'фывйцу', '', '', '', '', '', 0, 0, 0, '', '', '2016-09-06 15:42:35'),
(47, 1, 0, 0, '', 0, '', '', '', '', '', '', 0, 0, 0, '', '', '2016-09-09 20:22:26');

-- --------------------------------------------------------

--
-- Структура таблицы `menusettings`
--

CREATE TABLE IF NOT EXISTS `menusettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `link` varchar(20) COLLATE cp1251_ukrainian_ci NOT NULL,
  `active` int(1) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `submenu` int(1) NOT NULL DEFAULT '0',
  `title` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `external` int(1) NOT NULL DEFAULT '0',
  `externalSettings` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `parent` int(11) NOT NULL DEFAULT '0',
  `folder` int(1) NOT NULL DEFAULT '0',
  `useimg` int(1) NOT NULL DEFAULT '1',
  `usetext` int(1) NOT NULL DEFAULT '1',
  `useletters` int(1) NOT NULL DEFAULT '1',
  `usetemplate` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=18 ;

--
-- Дамп данных таблицы `menusettings`
--

INSERT INTO `menusettings` (`id`, `name`, `link`, `active`, `prior`, `submenu`, `title`, `external`, `externalSettings`, `filter`, `parent`, `folder`, `useimg`, `usetext`, `useletters`, `usetemplate`) VALUES
(3, 'Шаблонизатор', 'filters', 1, 50, 1, 'static:форма->поле\nформы->полей\nформу->поле\nформы->поля', 0, '', 0, 0, 0, 0, 0, 0, 0),
(9, 'Города', 'towns', 1, 30, 1, 'static:Страна->Область->Район->Город->Микрорайон\nстран->областей->районов->городов->микрорайонов\nстрану->область->район->город->микрорайон\n->->->->:rules:{23:{"0":"test"}}', 1, '', 1, 0, 0, 1, 1, 1, 1),
(15, 'Каталог товаров', 'items', 1, 10, 1, 'catalog:группа->позиция\nгруппы->позиций\nгруппу->позицию\nгруппы->позиции', 0, '', 1, 0, 0, 1, 1, 1, 1),
(16, 'Текстовые страницы', 'texts', 1, 40, 0, 'single:страница\nстраница\nстраницу\nстраница', 0, '', 16, 0, 0, 1, 1, 1, 1),
(17, 'Выбор цветов', 'colors', 1, 20, 0, 'single:Цвет\r\nцветов\r\nцвет\r\n', 0, '', 16, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `arrayName` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `value` varchar(255) COLLATE cp1251_ukrainian_ci NOT NULL,
  `unit` varchar(20) COLLATE cp1251_ukrainian_ci NOT NULL,
  `comment` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `prior` int(3) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `arrayName`, `value`, `unit`, `comment`, `prior`, `active`) VALUES
(5, 'Список администраторов', 'admins', '', '', '', 5, 1),
(6, 'Список языков', 'languages', 'rus-рус-русский,ukr-укр-украинский,eng-eng-english,frn-frn-france,dch-dch-doiche', '', '', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `test`
--

CREATE TABLE IF NOT EXISTS `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `folder` int(11) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `letters` varchar(60) COLLATE cp1251_ukrainian_ci NOT NULL,
  `content` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `metaDescription` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `texts`
--

CREATE TABLE IF NOT EXISTS `texts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `folder` int(11) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `letters` varchar(60) COLLATE cp1251_ukrainian_ci NOT NULL,
  `content` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `metaDescription` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `texts`
--

INSERT INTO `texts` (`id`, `parent`, `folder`, `prior`, `link`, `filter`, `name`, `name_ukr`, `name_eng`, `letters`, `content`, `visible`, `tmp`, `trash`, `metaTitle`, `metaDescription`, `addDate`) VALUES
(1, 0, 0, 0, '', 0, 'тест, однако', '', '', '', '', 0, 0, 0, '', '', '2016-09-06 15:42:12');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
