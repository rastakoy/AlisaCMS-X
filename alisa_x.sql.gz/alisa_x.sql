-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Ноя 11 2016 г., 05:42
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `alisa_x`
--

-- --------------------------------------------------------

--
-- Структура таблицы `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(20) COLLATE cp1251_ukrainian_ci NOT NULL,
  `password` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `admins`
--

INSERT INTO `admins` (`id`, `login`, `password`, `addDate`) VALUES
(1, 'superadmin', '098f6bcd4621d373cade4e832627b4f6', '0000-00-00 00:00:00'),
(2, 'admin', '098f6bcd4621d373cade4e832627b4f6', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `assembly`
--

CREATE TABLE IF NOT EXISTS `assembly` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `folder` int(11) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `letters` varchar(60) COLLATE cp1251_ukrainian_ci NOT NULL,
  `content` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `metaDescription` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime DEFAULT NULL,
  `orderId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `colors`
--

CREATE TABLE IF NOT EXISTS `colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `folder` int(11) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `letters` varchar(60) COLLATE cp1251_ukrainian_ci NOT NULL,
  `content` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `metaDescription` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime DEFAULT NULL,
  `colorize` int(5) NOT NULL,
  `mini` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `price` double NOT NULL,
  `newopt` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `colors`
--

INSERT INTO `colors` (`id`, `parent`, `folder`, `prior`, `link`, `filter`, `name`, `name_ukr`, `name_eng`, `letters`, `content`, `visible`, `tmp`, `trash`, `metaTitle`, `metaDescription`, `addDate`, `colorize`, `mini`, `price`, `newopt`) VALUES
(1, 0, 0, 10, '', 0, 'test', '', '', '', '', 0, 0, 0, '', '', '2016-09-08 19:33:25', 0, '0', 0, ''),
(2, 0, 0, 20, '', 0, 'zxcqwe', '', '', '', '', 0, 0, 0, '', '', '2016-09-08 19:33:28', 0, '0', 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `parent` int(11) NOT NULL,
  `letters` varchar(39) COLLATE cp1251_ukrainian_ci NOT NULL,
  `folder` int(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `read` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `option`, `parent`, `letters`, `folder`, `comment`, `read`) VALUES
(1, 'items', 14, 'AAAAAB', 0, 'Новый коммент', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `filters`
--

CREATE TABLE IF NOT EXISTS `filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL DEFAULT '0',
  `name` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_dch` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_frn` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(20) COLLATE cp1251_ukrainian_ci NOT NULL,
  `tableName` varchar(30) COLLATE cp1251_ukrainian_ci NOT NULL,
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `type` varchar(20) COLLATE cp1251_ukrainian_ci NOT NULL,
  `datatype` varchar(30) COLLATE cp1251_ukrainian_ci NOT NULL,
  `datalength` int(3) NOT NULL,
  `datadefault` varchar(30) COLLATE cp1251_ukrainian_ci NOT NULL,
  `folder` int(1) NOT NULL DEFAULT '0',
  `config` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `trash` int(1) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `txtfield` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `txtfield_eng` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `txtfield_ukr` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `external` int(1) NOT NULL DEFAULT '0',
  `inFilter` int(1) NOT NULL DEFAULT '0',
  `addDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=53 ;

--
-- Дамп данных таблицы `filters`
--

INSERT INTO `filters` (`id`, `parent`, `name`, `name_eng`, `name_dch`, `name_frn`, `name_ukr`, `tableName`, `link`, `type`, `datatype`, `datalength`, `datadefault`, `folder`, `config`, `visible`, `trash`, `prior`, `tmp`, `txtfield`, `txtfield_eng`, `txtfield_ukr`, `external`, `inFilter`, `addDate`) VALUES
(1, 0, 'Каталог-товаров 3', '', '', '', 'ukr', '', 'filter-1', '', '', 0, '', 1, '', 1, 0, 10, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(2, 1, 'Название', '', '', '', 'Назва', '', 'name', '', 'varchar', 150, '', 0, '', 1, 0, 10, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(3, 1, 'Миниописание', '', '', '', '', '', 'mini', '', 'varchar', 100, '', 0, '', 1, 0, 20, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(4, 1, 'HTML-путь', '', '', '', '', '', 'link', '', 'varchar', 100, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"link","isprev":"0"}', 1, 0, 30, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(5, 1, 'Родитель', '', '', '', '', '', 'parent', '', 'int:parent', 11, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"parent","isprev":"0"}', 1, 0, 40, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(6, 1, 'Цена', '', '', '', '', '', 'price', '', 'double:price', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"price","isprev":"0"}', 1, 0, 50, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(7, 1, 'Изображения', '', '', '', '', '', 'images', '', 'virtual', 0, '', 0, '{"connectors":{"table":"images","fields":{"0":{"connector":"table","port":"images.table"},"1":{"connector":"table.id","port":"images.externalId"}}}}', 1, 0, 90, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(8, 1, 'Описание', '', '', '', '', '', 'content', '', 'text:tinymce', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"content","isprev":"0"}', 1, 0, 100, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(9, 1, 'Показ в сайте', '', '', '', '', '', 'visible', '', 'int:checkbox', 1, '1', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"visible","isprev":"0"}', 0, 0, 150, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(10, 1, 'Буквенный код', '', '', '', '', '', 'letters', '', 'varchar', 30, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"letters","isprev":"0"}', 0, 0, 110, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(11, 1, 'Дата добавления', '', '', '', '', '', 'addDate', '', 'datetime', 0, '', 0, '', 1, 0, 120, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(12, 1, 'Заголовок', '', '', '', '', '', 'metaTitle', '', 'varchar', 200, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"metaTitle","isprev":"0"}', 1, 0, 130, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(13, 1, 'Описание заголовка', '', '', '', '', '', 'metaDescription', '', 'varchar', 200, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"metaDescription","isprev":"0"}', 1, 0, 140, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(14, 1, 'Новая запись', '', '', '', '', '', 'tmp', '', '', 0, '', 0, '{"filtertype":"","datatype":"1","tablename":"items","fieldname":"","isprev":"0"}', 1, 1, 130, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(15, 1, 'Цвета', '', '', '', '', '', 'newopt', '', 'varchar:colors', 50, '', 0, '', 0, 0, 160, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(16, 0, 'Цвета', '', '', '', '', '', 'colors', '', '', 0, '', 1, '', 1, 0, 40, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(17, 16, 'Название цвета', '', '', '', '', '', 'name', '', 'varchar', 20, '', 0, '', 1, 0, 10, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(18, 16, 'Выбор цвета', '', '', '', '', '', 'color', '', 'varchar:colors', 7, '#FF0000', 0, '', 1, 0, 30, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(31, 16, 'test', '', '', '', '', '', 'asdewq', '', 'int:port', 1, '', 0, '', 0, 0, 20, 0, '', '', '', 0, 0, '2016-09-09 20:33:03'),
(32, 16, 'test 23', '', '', '', '', '', 'colorize', '', 'varchar:colors', 7, '23', 0, '', 0, 0, 40, 0, '', '', '', 0, 0, '2016-09-09 21:08:49'),
(33, 0, 'Новый фильтр', '', '', '', '', '', 'newfilter', '', '', 0, '', 1, '', 1, 0, 50, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(34, 33, 'Название', '', '', '', '', '', 'name', '', 'varchar', 100, '', 0, '', 0, 0, 0, 0, '', '', '', 0, 0, '2016-09-09 21:20:46'),
(35, 0, 'Изображения', '', '', '', '', '', 'images', '', '', 0, '', 1, '', 1, 0, 30, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(36, 35, 'ID родителя', '', '', '', '', '', 'externalId', '', 'int:port', 11, '', 0, '', 1, 0, 10, 0, '', '', '', 0, 0, '2016-09-10 12:38:15'),
(37, 35, 'Родительская таблица', '', '', '', '', '', 'table', '', 'varchar:port', 50, '', 0, '', 1, 0, 20, 0, '', '', '', 0, 0, '2016-09-10 12:40:43'),
(38, 0, 'Единицы измерений', '', '', '', '', '', 'mesurunits', '', '', 0, '', 1, '', 1, 0, 60, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(39, 38, 'Название', '', '', '', '', '', 'name', '', 'varchar', 100, '', 0, '', 1, 0, 10, 0, '', '', '', 0, 0, '2016-09-15 23:14:29'),
(40, 38, 'Описание', '', '', '', '', '', 'content', '', 'text:tinymce', 0, '', 0, '', 1, 0, 30, 0, '', '', '', 0, 0, '2016-09-15 23:15:36'),
(41, 38, 'Отображение', '', '', '', '', '', 'visible', '', 'int:checkbox', 1, '1', 0, '', 1, 0, 40, 0, '', '', '', 0, 0, '2016-09-15 23:18:38'),
(42, 38, 'Название сокращенное', '', '', '', '', '', 'shortname', '', 'varchar', 10, '', 0, '', 1, 0, 20, 0, '', '', '', 0, 0, '2016-09-15 23:19:14'),
(43, 1, 'Единица длины', '', '', '', '', '', '', '', 'int:connector', 0, '', 0, '{"connector":{"table":"measurunits","data":{"0":{"field":"mulength","fieldName":"Мера длины","default":"1"},"1":{"field":"musublength","fieldName":"География","default":"11"},"2":{"field":"asdfdfd","fieldName":"Единица","default":""}}}}', 1, 0, 70, 0, '', '', '', 0, 0, '2016-09-15 23:28:11'),
(44, 0, 'Комментарии', '', '', '', '', '', 'comments', '', '', 0, '', 1, '', 1, 0, 20, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(45, 1, 'Сохранение данных', '', '', '', '', '', '', '', 'virtual:saveblock', 0, '', 0, '{"connectors":{"table":"images","fields":{}}}', 1, 0, 170, 0, '', '', '', 0, 0, '2016-10-21 20:10:47'),
(46, 1, 'Сохранение данных', '', '', '', '', '', '', '', 'virtual:saveblock', 0, '', 0, '{"connectors":{"table":"images","fields":{}}}', 1, 0, 80, 0, '', '', '', 0, 0, '2016-10-21 20:19:27'),
(47, 1, 'Штрихкод', '', '', '', '', '', '', '', 'virtual:barcode', 0, '', 0, '{"connectors":{"table":"images","fields":{}}}', 1, 0, 60, 0, '', '', '', 0, 0, '2016-11-08 21:56:05'),
(48, 0, 'Список заказов', '', '', '', '', '', 'orders', '', '', 0, '', 1, '', 1, 0, 70, 0, '', '', '', 0, 0, '0000-00-00 00:00:00'),
(49, 48, 'Дата заказа', '', '', '', '', '', 'addDate', '', 'datetime', 0, '', 0, '', 1, 0, 20, 0, '', '', '', 0, 0, '2016-11-10 01:31:53'),
(50, 48, 'Сборка заказа', '', '', '', '', '', '', '', 'virtual', 0, '', 0, '{"connectors":{"table":"assembly","fields":{"0":{"connector":"id","port":"assembly.orderId"}}}}', 1, 0, 30, 0, '', '', '', 0, 0, '2016-11-10 01:34:50'),
(51, 48, 'Название', '', '', '', '', '', 'name', '', 'varchar', 100, '', 0, '', 1, 0, 10, 0, '', '', '', 0, 0, '2016-11-10 02:42:29'),
(52, 48, 'Сохранение', '', '', '', '', '', '', '', 'virtual:saveblock', 0, '', 0, '{"connectors":{"table":"images","fields":{}}}', 1, 0, 40, 0, '', '', '', 0, 0, '2016-11-10 02:45:37');

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prior` int(11) NOT NULL DEFAULT '0',
  `userId` int(11) NOT NULL,
  `name` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `cont` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `alt` varchar(255) COLLATE cp1251_ukrainian_ci NOT NULL,
  `title` varchar(255) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime NOT NULL,
  `externalId` int(11) NOT NULL DEFAULT '0',
  `table` varchar(255) COLLATE cp1251_ukrainian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `images`
--

INSERT INTO `images` (`id`, `prior`, `userId`, `name`, `cont`, `alt`, `title`, `addDate`, `externalId`, `table`) VALUES
(1, 0, 0, '1.jpg', '', '', '', '0000-00-00 00:00:00', 12, 'items'),
(2, 0, 0, '2.jpg', '', '', '', '0000-00-00 00:00:00', 13, 'items'),
(3, 0, 0, '3.jpg', '', '', '', '0000-00-00 00:00:00', 14, 'items'),
(4, 0, 0, '4.jpg', '', '', '', '0000-00-00 00:00:00', 15, 'items');

-- --------------------------------------------------------

--
-- Структура таблицы `items`
--

CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `folder` int(11) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `name` varchar(150) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `letters` varchar(60) COLLATE cp1251_ukrainian_ci NOT NULL,
  `content` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `content_ukr` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `metaDescription` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime DEFAULT NULL,
  `mini` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `newopt` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `price` double NOT NULL,
  `mulength` int(11) NOT NULL,
  `musublength` int(11) NOT NULL,
  `asdfdfd` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=17 ;

--
-- Дамп данных таблицы `items`
--

INSERT INTO `items` (`id`, `parent`, `folder`, `prior`, `link`, `filter`, `name`, `name_ukr`, `name_eng`, `letters`, `content`, `content_ukr`, `visible`, `tmp`, `trash`, `metaTitle`, `metaDescription`, `addDate`, `mini`, `newopt`, `price`, `mulength`, `musublength`, `asdfdfd`) VALUES
(1, 0, 1, 10, 'kabel__provod_komplektuuie', 0, 'Кабель, провод, комплектующие', '', '', 'AAA', '', '', 1, 0, 0, '', '', NULL, '', '', 0, 0, 0, 0),
(4, 0, 1, 20, 'sistemi_prokladki_kabelya', 0, 'Системы прокладки кабеля', '', '', 'AAB', '', '', 1, 0, 0, '', '', NULL, '', '', 0, 0, 0, 0),
(5, 1, 1, 10, 'kabelya_dlya_sistem_svyazi', 0, 'Кабеля для систем связи', '', '', 'AAAAAA', '', '', 1, 0, 0, '', '', NULL, '', '', 0, 0, 0, 0),
(6, 1, 1, 20, 'kabel__medniy', 0, 'Кабель медный', '', '', 'AAAAAB', '', '', 1, 0, 0, '', '', NULL, '', '', 0, 0, 0, 0),
(7, 4, 1, 0, 'korob_i_furnitura', 0, 'Короб и фурнитура', '', '', 'AABAAA', '', '', 1, 0, 0, '', '', NULL, '', '', 0, 0, 0, 0),
(8, 4, 1, 0, 'truba_gibkaya_gofra_metalorukav', 0, 'Труба гибкая (гофра), металорукав', '', '', 'AABAAB', '', '', 1, 0, 0, '', '', NULL, '', '', 0, 0, 0, 0),
(9, 7, 1, 0, 'korob_kopos', 0, 'Короб KOPOS', '', '', 'AABAAAAAA', '', '', 1, 0, 0, '', '', NULL, '', '', 0, 0, 0, 0),
(10, 7, 1, 0, 'korob_tm_220', 0, 'Короб тм 220', '', '', 'AABAAAAAB', '', '', 1, 0, 0, '', '', NULL, '', '', 0, 0, 0, 0),
(11, 4, 1, 0, 'truba_gladkaya_kopos', 0, 'Труба гладкая (Копос)', '', '', 'AABAAC', '', '', 1, 0, 0, '', '', NULL, '', '', 0, 0, 0, 0),
(12, 8, 0, 0, '12345', 0, 'Трубка гибкая 16 (kopos) test', '', '', 'AABAAB', '', '', 1, 0, 0, '', '', '2016-10-12 01:15:52', '', '', 0, 1, 11, 3),
(13, 8, 0, 0, '', 0, 'металлорукав 10 IEK', '', '', '', '', '', 1, 0, 0, '', '', '2016-10-12 01:28:26', '', '', 0, 1, 11, 4),
(14, 5, 0, 10, 'vitaya_para_uutp__kat_5e', 0, 'Витая пара UTP кат 5е4', 'Название украинское', '', 'AAAAAA', '<p>test</p>', '', 1, 0, 0, '', '', '2016-10-12 17:10:06', '', '', 0, 1, 11, 2),
(15, 5, 0, 20, 'kabel__signal_niy_6h022_ekranirovanniy', 0, 'кабель сигнальный 6х0.22 (экранированный)', 'укро', '', 'AAAAAA', '<p>Просто</p>', '<p>укро описание</p>', 1, 0, 0, '', '', '2016-10-12 18:23:57', '', '', 0, 1, 11, 2),
(16, 1, 1, 30, 'kabel__aluminieviy', 0, 'Кабель алюминиевый', '', '', 'AAAAAC', '', '', 1, 0, 0, '', '', NULL, '', '', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `measurunits`
--

CREATE TABLE IF NOT EXISTS `measurunits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `folder` int(11) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `letters` varchar(60) COLLATE cp1251_ukrainian_ci NOT NULL,
  `content` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `metaDescription` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime DEFAULT NULL,
  `shortname` varchar(10) COLLATE cp1251_ukrainian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=15 ;

--
-- Дамп данных таблицы `measurunits`
--

INSERT INTO `measurunits` (`id`, `parent`, `folder`, `prior`, `link`, `filter`, `name`, `name_ukr`, `name_eng`, `letters`, `content`, `visible`, `tmp`, `trash`, `metaTitle`, `metaDescription`, `addDate`, `shortname`) VALUES
(1, 0, 1, 10, 'meri_dlini', 0, 'Меры длины', '', '', '', '', 1, 0, 0, '', '', NULL, ''),
(2, 11, 0, 10, '', 0, 'Километр', '', '', '', '', 1, 0, 0, '', '', '2016-09-15 23:17:05', 'км.'),
(3, 11, 0, 30, '', 0, 'Сантиметр', '', '', '', '', 1, 0, 0, '', '', '2016-09-15 23:21:20', 'см.'),
(4, 11, 0, 40, '', 0, 'Миллиметр', '', '', '', '', 1, 0, 0, '', '', '2016-09-15 23:21:42', 'мм.'),
(5, 0, 1, 20, 'weight', 0, 'Вес', '', '', '', '', 1, 0, 0, '', '', NULL, ''),
(6, 5, 0, 10, '', 0, 'Килограмм', '', '', '', '', 1, 0, 0, '', '', '2016-09-15 23:24:58', 'kg'),
(7, 5, 0, 20, '', 0, 'Грамм', '', '', '', '', 1, 0, 0, '', '', '2016-09-15 23:25:17', 'г.'),
(8, 5, 0, 30, '', 0, 'Миллиграмм', '', '', '', '', 1, 0, 0, '', '', '2016-09-15 23:25:37', 'мг.'),
(9, 10, 0, 20, '', 0, 'Дюйм', '', '', '', '', 1, 0, 0, '', '', '2016-09-15 23:26:29', 'дм.'),
(10, 1, 1, 0, 'usa', 0, 'Длины США', '', '', '', '', 1, 0, 0, '', '', NULL, ''),
(11, 1, 1, 0, 'euro', 0, 'Меры Европы', '', '', '', '', 1, 0, 0, '', '', NULL, ''),
(12, 1, 1, 0, 'russia', 0, 'Меры России', '', '', '', '', 1, 0, 0, '', '', NULL, ''),
(13, 12, 0, 10, '', 0, 'Аршин', '', '', '', '', 1, 0, 0, '', '', '2016-09-26 19:01:03', 'арш.'),
(14, 12, 0, 20, '', 0, 'Вершок', '', '', '', '', 1, 0, 0, '', '', '2016-09-26 19:01:24', 'верш.');

-- --------------------------------------------------------

--
-- Структура таблицы `menusettings`
--

CREATE TABLE IF NOT EXISTS `menusettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `link` varchar(20) COLLATE cp1251_ukrainian_ci NOT NULL,
  `active` int(1) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `submenu` int(1) NOT NULL DEFAULT '0',
  `title` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `external` int(1) NOT NULL DEFAULT '0',
  `externalSettings` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `parent` int(11) NOT NULL DEFAULT '0',
  `folder` int(1) NOT NULL DEFAULT '0',
  `useimg` int(1) NOT NULL DEFAULT '1',
  `usetext` int(1) NOT NULL DEFAULT '1',
  `useletters` int(1) NOT NULL DEFAULT '1',
  `usetemplate` int(1) NOT NULL DEFAULT '1',
  `comments` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=21 ;

--
-- Дамп данных таблицы `menusettings`
--

INSERT INTO `menusettings` (`id`, `name`, `link`, `active`, `prior`, `submenu`, `title`, `external`, `externalSettings`, `filter`, `parent`, `folder`, `useimg`, `usetext`, `useletters`, `usetemplate`, `comments`) VALUES
(3, 'Шаблонизатор', 'filters', 1, 80, 1, 'static:форма->поле\nформы->полей\nформу->поле\nформы->поля', 0, '', 0, 0, 0, 0, 0, 0, 0, 0),
(9, 'Города', 'towns', 0, 60, 1, 'static:Страна->Область->Район->Город->Микрорайон\nстран->областей->районов->городов->микрорайонов\nстрану->область->район->город->микрорайон\n->->->->:rules:{23:{"0":"test"}}', 1, '', 1, 0, 0, 1, 1, 1, 1, 0),
(15, 'Каталог товаров', 'items', 1, 30, 1, 'catalog:группа->позиция\nгруппы->позиций\nгруппу->позицию\nгруппы->позиции', 0, '', 1, 0, 0, 1, 1, 1, 1, 1),
(16, 'Текстовые страницы', 'texts', 0, 70, 0, 'single:страница\nстраница\nстраницу\nстраница', 0, '', 16, 0, 0, 1, 1, 1, 1, 0),
(17, 'Выбор цветов', 'colors', 0, 40, 0, 'single:Цвет\nцветов\nцвет\n', 0, '', 1, 0, 0, 0, 0, 0, 0, 0),
(18, 'Единицы измерений', 'measurunits', 0, 50, 1, 'static:Тип->Субтип->Название\nТип->Субтип->Название\nТип->Субтип->Название\nТип->Субтип->Название', 0, '', 38, 0, 0, 1, 1, 1, 1, 0),
(19, 'Список заказов', 'orders', 0, 10, 1, 'static:Статус->Заказ\nСтатус->Заказ\nСтатус->Заказ\nСтатус->Заказ', 0, '', 48, 0, 0, 1, 0, 0, 1, 0),
(20, 'Сборка заказа', 'assembly', 0, 20, 0, 'single:Товар\r\nтоваров\r\nтовар', 0, '', 0, 0, 0, 1, 1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `folder` int(11) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `letters` varchar(60) COLLATE cp1251_ukrainian_ci NOT NULL,
  `content` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `metaDescription` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime DEFAULT NULL,
  `orderStatus` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `parent`, `folder`, `prior`, `link`, `filter`, `name`, `name_ukr`, `name_eng`, `letters`, `content`, `visible`, `tmp`, `trash`, `metaTitle`, `metaDescription`, `addDate`, `orderStatus`) VALUES
(1, 0, 0, 10, 'new', 0, '000001', '', '', '', '', 1, 0, 0, '', '', NULL, 0),
(2, 0, 0, 30, '', 0, '000002', '', '', '', '', 1, 0, 0, '', '', '2016-11-10 01:28:11', 0),
(3, 0, 0, 20, '', 0, '000003', '', '', '', '', 1, 0, 0, '', '', '2016-11-10 04:51:56', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `orderstatuses`
--

CREATE TABLE IF NOT EXISTS `orderstatuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `folder` int(11) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `letters` varchar(60) COLLATE cp1251_ukrainian_ci NOT NULL,
  `content` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `metaDescription` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `orderstatuses`
--

INSERT INTO `orderstatuses` (`id`, `parent`, `folder`, `prior`, `link`, `filter`, `name`, `name_ukr`, `name_eng`, `letters`, `content`, `visible`, `tmp`, `trash`, `metaTitle`, `metaDescription`, `addDate`) VALUES
(1, 0, 0, 10, 'new', 0, 'Новый заказ', '', '', '', '', 1, 0, 0, '', '', NULL),
(2, 0, 0, 20, 'working', 0, 'В обработке', '', '', '', '', 1, 0, 0, '', '', NULL),
(3, 0, 0, 30, 'moneytake', 0, 'Оплату получили', '', '', '', '', 1, 0, 0, '', '', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `arrayName` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `value` varchar(255) COLLATE cp1251_ukrainian_ci NOT NULL,
  `unit` varchar(20) COLLATE cp1251_ukrainian_ci NOT NULL,
  `comment` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `prior` int(3) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `arrayName`, `value`, `unit`, `comment`, `prior`, `active`) VALUES
(5, 'Список администраторов', 'admins', '', '', '', 5, 1),
(6, 'Список языков', 'languages', 'rus-рус-русский,ukr-укр-украинский,eng-eng-english,frn-frn-france,dch-dch-doiche', '', '', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `test`
--

CREATE TABLE IF NOT EXISTS `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `folder` int(11) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `letters` varchar(60) COLLATE cp1251_ukrainian_ci NOT NULL,
  `content` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `metaDescription` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `texts`
--

CREATE TABLE IF NOT EXISTS `texts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `folder` int(11) NOT NULL DEFAULT '0',
  `prior` int(3) NOT NULL DEFAULT '0',
  `link` varchar(50) COLLATE cp1251_ukrainian_ci NOT NULL,
  `filter` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_ukr` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `name_eng` varchar(100) COLLATE cp1251_ukrainian_ci NOT NULL,
  `letters` varchar(60) COLLATE cp1251_ukrainian_ci NOT NULL,
  `content` text COLLATE cp1251_ukrainian_ci NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1',
  `tmp` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `metaDescription` varchar(200) COLLATE cp1251_ukrainian_ci NOT NULL,
  `addDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 COLLATE=cp1251_ukrainian_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `texts`
--

INSERT INTO `texts` (`id`, `parent`, `folder`, `prior`, `link`, `filter`, `name`, `name_ukr`, `name_eng`, `letters`, `content`, `visible`, `tmp`, `trash`, `metaTitle`, `metaDescription`, `addDate`) VALUES
(1, 0, 0, 0, '', 0, 'тест, однако', '', '', '', '', 0, 0, 0, '', '', '2016-09-06 15:42:12');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
