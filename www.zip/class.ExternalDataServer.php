<?php
class ExternalDataServer {
	
	public $__EXHOST = "localhost";
	public $__EXDBNAME = "external";
	public $__EXDBUSER = "root";
	public $__EXDBPASSWORD = "";
	public $__EXDBENCODE = "utf8";
	
	function __construct($param1 = '', $param2 = '', $param3 = '', $param4 = ''){
		$params = array('__EXHOST' => $param1, '__EXDBNAME' => $param2, '__EXDBUSER' => $param3, '__EXDBPASSWORD' => $param4);
		foreach($params as $key => $param){
			$params[$key] = ($param == '' ? $this->$key : $param);
		}
		$link=mysql_connect($params['__EXHOST'],$params['__EXDBUSER'],$params['__EXDBPASSWORD']) or die ("ERROR 1 - Can't connect to database");
		$s=mysql_select_db($params['__EXDBNAME'], $link) or die("ERROR 2 - DB selection failure");
		$resp = mysql_query("SET NAMES ".$this->__EXDBENCODE);
	}
	
	/**
	
	*/
	function getData($data){
		$sql = "SELECT * FROM `$data[table]` ";
		if(is_array($data['params'])){ $sql.= " WHERE "; foreach($data['params'] as $key=>$value){
			if(preg_match("/^rlike/", $value)){
				$value = preg_replace("/rlike.*\(/", '', $value);
				$value = str_replace(")", '', $value);
				$value = preg_replace("/=/", "` RLIKE ('", $value);
				$value = "`".$value."')";
			}elseif(preg_match("/^search/", $value)){
				$value = preg_replace("/search.*(/", '', $value);
				$value = str_replace(")", '', $value);
				$value = preg_replace("/=/", "`='", $value);
				$value = "`".$value."'";
			}elseif(preg_match("/>=/", $value)){
				$value = preg_replace("/>=/", "`>='", $value);
				$value = "`".$value."'";
			}elseif(preg_match("/<=/", $value)){
				$value = preg_replace("/<=/", "`<='", $value);
				$value = "`".$value."'";
			}elseif(preg_match("/</", $value)){
				$value = preg_replace("/</", "`<'", $value);
				$value = "`".$value."'";
			}elseif(preg_match("/>/", $value)){
				$value = preg_replace("/>/", "`>'", $value);
				$value = "`".$value."'";
			}elseif(preg_match("/=/", $value)){
				$value = preg_replace("/=/", "`='", $value);
				$value = "`".$value."'";
			}
			$asql .= "AND $value ";
		}}
		$sql .= preg_replace("/^AND/", '', $asql);
		if($data['order']){
			$sql .= " ORDER BY `$data[order]` ";
		}
		if($data['orderType']){
			$sql .= " ".(strtoupper($data['orderType']))." ";
		}
		if($data['limit']){
			$sql .= " LIMIT ".$data['limit']." ";
		}
		//echo $sql."<br/>\n";
		$resp = mysql_query($sql);
		$returns['result'] = 'false';
		if($resp){
			$returns['result'] = 'true';
			if(mysql_num_rows($resp)>0){
				$returns['count'] = mysql_num_rows($resp);
				while($row=mysql_fetch_assoc($resp)){
					$returns['data'][] = $row;
				}
			}else{
				$returns['count'] = '0';
			}
		}
		//echo "<pre>"; print_r($returns); echo "</pre>";
		return $returns;
	}
	
	/**
	
	*/
	function addData($params){
		$data = $params['params'];
		if($data['parent']==''){ $data['parent']='0'; }
		$sql = "INSERT INTO `$params[table]` ";
		$keys = '(';
		$vals = '(';
		foreach($data as $key=>$value){
			$akeys .= ", `$key`";
			$avals .= ", '$value'";
		}
		$akeys = preg_replace("/^,/", '', $akeys);
		$avals = preg_replace("/^,/", '', $avals);
		$keys .= $akeys.")";
		$vals .= $avals.")";
		$sql .= " $keys VALUES $vals";
		//echo $sql;
		$resp = mysql_query($sql);
		if($resp){
			$subResp = mysql_query("SELECT * FROM `$params[table]` ORDER BY `id` DESC LIMIT 0,1 ");
			$item = mysql_fetch_assoc($subResp);
			$this->setLetters($item['id'], $params['table']);
			$this->addToHistory($sql);
			$returns['result'] = 'true';
			$returns['count'] = '1';
			$returns['data']['0'] = $item;
			$returns['data']['0']['itemId'] = $item['id'];
		}else{
			$returns['result'] = 'false';
		}
		return $returns;
	}
	
	/**
	
	*/
	function editData($params){
		$DBkeys = $this->getTableKeys($params['table']);
		$data = $params['params'];
		$langPrefix = $params['lang'];
		if($data['parent']==''){ $data['parent']='0'; }
		$sql = "UPDATE `$params[table]` SET ";
		//*********************************
		if(is_array($params['params'])){ foreach($params['params'] as $key=>$value){
			//$value = str_replace("'", "\\'", $value);
			if($langPrefix!=''){ foreach($DBkeys as $field){ $prega = "/$key$langPrefix\$/"; if(preg_match($prega, $field['Field'], $matches)){
				$asql .= ", `$key$langPrefix`='$value'";
			}}}else{
				$asql .= ", `$key`='$value'";
			}
		}}
		$asql = preg_replace("/^,/", '', $asql);
		$sql .= $asql;
		$asql = "";
		//*********************************
		if(is_array($params['where'])){ $sql.= " WHERE "; foreach($params['where'] as $key=>$value){
			if(preg_match("/>=/", $value)){
				$value = preg_replace("/>=/", "`>='", $value);
				$value = "`".$value."'";
			}elseif(preg_match("/<=/", $value)){
				$value = preg_replace("/<=/", "`<='", $value);
				$value = "`".$value."'";
			}elseif(preg_match("/</", $value)){
				$value = preg_replace("/</", "`<'", $value);
				$value = "`".$value."'";
			}elseif(preg_match("/>/", $value)){
				$value = preg_replace("/>/", "`>'", $value);
				$value = "`".$value."'";
			}elseif(preg_match("/=/", $value)){
				$value = preg_replace("/=/", "`='", $value);
				$value = "`".$value."'";
			}
			$asql .= "AND $value ";
		}}
		$sql .= preg_replace("/^AND/", '', $asql);
		//echo $sql;
		$resp = mysql_query($sql);
		if($resp){
			//if($params['where']['id']){
				$this->setLetters($params['where']['id'], $params['table']);
			//}
			$this->addToHistory($sql);
			$returns['result'] = 'true';
		}else{
			$returns['result'] = 'false';
		}
		return $returns;
	}
	
	/**
	
	*/
	function deleteData(){
		
		addToHistory($sql);
	}
	
	/**
	
	*/
	function addToHistory($sql){
		$sql = str_replace("'", "\\'", $sql);
		$sql = str_replace("\\\\'", "\\\\\\'", $sql);
		$resp = mysql_query("INSERT INTO `history` (`content`) VALUES ('$sql')");
	}
	
	/**
	
	*/
	function getTableKeys($table){
		$resp = mysql_query("SHOW FIELDS FROM `$table`");
		while($field=mysql_fetch_assoc($resp)){
			$fields[] = $field;
		}
		return $fields;
	}
	
	/**
	
	*/
	function setLetters($id, $table){
		$letters = array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
		$prefix = '';
		$q = "SELECT * FROM `$table` WHERE `id`='$id' ";
		//echo $q."\n";
		$resp = mysql_query($q);
		$row = mysql_fetch_assoc($resp);
		if($row['parent']>0){
			$parResp = mysql_query("SELECT * FROM `$table` WHERE `id`='$row[parent]' ");
			$parentRow = mysql_fetch_assoc($parResp);
			$prefix = $parentRow['letters'];
		}
		$count_0=0;
		$count_1=0;
		$count_2=0;
		$resps = mysql_query("SELECT * FROM `$table` WHERE `parent`='$row[parent]' AND `folder`='1' ORDER BY `name` ASC ");
		while($rows=mysql_fetch_assoc($resps)){
			$word = $prefix.$letters[$count_2].$letters[$count_1].$letters[$count_0];
			$qqq = "SELECT * FROM `$table` WHERE `folder`='1' AND `parent`='$rows[id]' ORDER BY `name` ASC ";
			//echo "$qqq\n";
			//echo "\n$word\n----------------------\n\n";
			$respo = mysql_query("UPDATE `$table` SET `letters`='$word' WHERE `id`='$rows[id]' ");
			$childsResp = mysql_query($qqq);
			if(mysql_num_rows($childsResp)>0){
				$childsRow=mysql_fetch_assoc($childsResp);
				$this->setLetters($childsRow['id'], $table);
			}
			
			$respo = mysql_query("UPDATE `$table` SET `letters`='$word' WHERE `parent`='$rows[id]'  AND `folder`='0' ");
			
			$count_0++;
			if($count_0==count($letters)){
				$count_0 = 0;
				$count_1++;
				if($count_1==count($letters)){
					$count_0 = 0;
					$count_1 = 0;
					$count_2++;
				}
			}
		}
	}
	//*****************************************************
	
}