<?
//foreach($_GET as $key=>$value){exit;}
//$exit=true;foreach($_GET as $key=>$value){$exit=false;}if($exit){exit;}
$API_login = $_POST['API_login'];
$API_password = $_POST['API_password'];
$API_code = $_POST['API_code'];

$API_secrets['kraina'] = array("e807f1fcf82d132f9bb018ca6738a19f","bcd4621d37");
//$pass = "1234567890";
//echo md5($pass)."<br/>";
$code = md5('kraina'.'e807f1fcf82d132f9bb018ca6738a19f'.$API_secrets['kraina']['1']);
//$code = "d41d8cd98f00b204e9800998ecf8427e";
//echo "code=".$code."<br/>";
if(count($API_secrets[$API_login])=='0' || $API_secrets[$API_login]['0']!=$API_password){
	echo "{\"result\":\"error\"}";
	exit;
}else{
	
}

require_once("class.ExternalDataServer.php");
$classExternalServer = new ExternalDataServer();
//***************************************
//print_r($_POST);
$params = array();
$json = $_POST['json'];
if($json){
	$params = json_decode($json, true);
}
//***************************************
//print_r($params);
$action = $params['action'];
if(!$action){ $action='getData'; }
if($action=="getData"){
	$exData = $classExternalServer->getData($params);
}elseif($action=="addData"){
	$exData = $classExternalServer->addData($params);
}elseif($action=="editData"){
	$exData = $classExternalServer->editData($params);
}
echo json_encode($exData);
//print_r($exData);
?>